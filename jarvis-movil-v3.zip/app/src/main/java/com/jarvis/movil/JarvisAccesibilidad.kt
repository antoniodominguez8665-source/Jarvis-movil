package com.jarvis.movil

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Solo observa WhatsApp. Toca "Enviar" únicamente cuando JARVIS se lo pide
// (después de que usted confirma un mensaje por voz).
class JarvisAccesibilidad : AccessibilityService() {

    companion object {
        @Volatile var instancia: JarvisAccesibilidad? = null
        @Volatile private var pendienteHasta = 0L
        @Volatile private var alTerminar: ((Boolean) -> Unit)? = null

        fun activo(): Boolean = instancia != null

        fun armar(ms: Long, callback: (Boolean) -> Unit) {
            alTerminar = callback
            pendienteHasta = SystemClock.uptimeMillis() + ms
        }

        fun expirar() {
            val cb = alTerminar
            if (cb != null && pendienteHasta != 0L) {
                alTerminar = null
                pendienteHasta = 0L
                cb(false)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instancia = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instancia = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || pendienteHasta == 0L) return
        if (SystemClock.uptimeMillis() > pendienteHasta) {
            expirar()
            return
        }
        val raiz = rootInActiveWindow ?: return
        val boton = buscarEnviar(raiz) ?: return
        if (clickear(boton)) {
            val cb = alTerminar
            alTerminar = null
            pendienteHasta = 0L
            cb?.invoke(true)
        }
    }

    private fun buscarEnviar(raiz: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (paquete in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val porId = raiz.findAccessibilityNodeInfosByViewId("$paquete:id/send")
            if (porId != null && porId.isNotEmpty()) return porId[0]
        }
        for (etiqueta in listOf("Enviar", "Send")) {
            val lista = raiz.findAccessibilityNodeInfosByText(etiqueta)
            val nodo = lista?.firstOrNull { it.isClickable }
            if (nodo != null) return nodo
        }
        return null
    }

    private fun clickear(nodo: AccessibilityNodeInfo): Boolean {
        var actual: AccessibilityNodeInfo? = nodo
        var intentos = 0
        while (actual != null && intentos < 4) {
            if (actual.isClickable) {
                return actual.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            actual = actual.parent
            intentos++
        }
        return false
    }

    override fun onInterrupt() {}
}
