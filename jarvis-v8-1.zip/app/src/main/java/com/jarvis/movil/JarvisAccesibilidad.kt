package com.jarvis.movil

// Versión sin servicio de accesibilidad (Play Protect bloquea las apps que lo piden
// cuando se instalan fuera de la tienda). Se deja este objeto vacío para no cambiar el resto del código.
object JarvisAccesibilidad {
    fun activo(): Boolean = false
    fun armar(ms: Long, callback: (Boolean) -> Unit) {}
    fun expirar() {}
}
