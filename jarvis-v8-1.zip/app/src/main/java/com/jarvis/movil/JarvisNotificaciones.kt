package com.jarvis.movil

import android.app.Notification
import android.app.PendingIntent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MensajeWA(val clave: String, val chat: String, val texto: String, val intent: PendingIntent?)

// Lee solo las notificaciones de WhatsApp y las guarda para que JARVIS pueda leerlas en voz alta.
class JarvisNotificaciones : NotificationListenerService() {

    companion object {
        val mensajes = mutableListOf<MensajeWA>()
        @Volatile var conectado = false
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        conectado = true
        try {
            val activas = activeNotifications
            if (activas != null) {
                for (n in activas) procesar(n)
            }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        conectado = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) procesar(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val clave = sbn.key
        mensajes.removeAll { it.clave == clave }
    }

    private fun procesar(sbn: StatusBarNotification) {
        val paquete = sbn.packageName
        if (paquete != "com.whatsapp" && paquete != "com.whatsapp.w4b") return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category == Notification.CATEGORY_CALL) return
        val extras = n.extras ?: return
        val titulo = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        if (titulo == "WhatsApp") return

        val nuevos = mutableListOf<String>()
        @Suppress("DEPRECATION")
        val arr = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null && arr.isNotEmpty()) {
            for (item in arr) {
                val b = item as? Bundle ?: continue
                val t = b.getCharSequence("text")?.toString() ?: continue
                nuevos.add(t)
            }
        } else {
            val t = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            if (t != null) nuevos.add(t)
        }
        if (nuevos.isEmpty()) return

        val clave = sbn.key
        mensajes.removeAll { it.clave == clave }
        for (t in nuevos) {
            if (Regex("^\\d+ mensajes?.*", RegexOption.IGNORE_CASE).matches(t) || t.startsWith("Revisando")) continue
            mensajes.add(MensajeWA(clave, titulo, t, n.contentIntent))
        }
        while (mensajes.size > 60) mensajes.removeAt(0)
    }
}
