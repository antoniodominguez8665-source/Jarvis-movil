package com.jarvis.movil

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.widget.Toast
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

@SuppressLint("MissingPermission")
class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsListo = false
    private val pendientesHabla = AtomicInteger(0)
    private var hablando = false
    private var corriendo = false
    private var reconocedor: SpeechRecognizer? = null

    // Ventana de atención: tras hablarle, JARVIS atiende 30 s sin pedir "Jarvis".
    private var activo = false
    private var ultimaActividad = 0L
    private val ventanaMs = 30_000L

    private var pendiente: (() -> Unit)? = null
    private var pendienteHasta = 0L
    private var textoOriginal = ""

    private var wakeLock: PowerManager.WakeLock? = null
    private var llamadaSonando = false

    private val reintento = Runnable { escuchar() }
    private val fallbackLlamada = Runnable { anunciarLlamada(null) }
    private val patronJarvis = Regex("\\b(jarvis|yarvis|harvis|jarbis|garvis|jarvi)\\b")

    private val numeros = linkedMapOf(
        "una" to 1, "un" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10,
        "once" to 11, "doce" to 12, "quince" to 15, "veinte" to 20, "treinta" to 30,
        "cuarenta y cinco" to 45, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60
    )

    // ------------------------------------------------------------ ciclo de vida

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        corriendo = true
        try {
            crearNotificacion()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar: revise los permisos.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:escucha")
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire()

        tts = TextToSpeech(this, this)
        registrarReceptorLlamadas()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Este teléfono no tiene reconocimiento de voz disponible.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        crearReconocedor()
    }

    override fun onDestroy() {
        corriendo = false
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receptorLlamadas) } catch (e: Exception) { }
        reconocedor?.destroy()
        reconocedor = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun crearNotificacion() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS activo")
            .setContentText("Escuchando. Diga «Jarvis».")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ------------------------------------------------------------ voz (TTS)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("es", "MX"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale("es"))
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { terminoHabla() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { terminoHabla() }
        })
        ttsListo = true
        decir("Jarvis en línea, señor.")
    }

    private fun decir(texto: String) {
        main.post {
            if (!ttsListo || !corriendo) return@post
            hablando = true
            pendientesHabla.incrementAndGet()
            reconocedor?.cancel()
            main.removeCallbacks(reintento)
            val r = tts?.speak(texto, TextToSpeech.QUEUE_ADD, null, "j" + System.nanoTime())
            if (r != TextToSpeech.SUCCESS) terminoHabla()
        }
    }

    private fun terminoHabla() {
        main.post {
            if (pendientesHabla.decrementAndGet() <= 0) {
                pendientesHabla.set(0)
                hablando = false
                ultimaActividad = System.currentTimeMillis()
                main.removeCallbacks(reintento)
                main.postDelayed(reintento, 400)
            }
        }
    }

    // ------------------------------------------------------------ escucha

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (!corriendo || hablando) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    Toast.makeText(this@JarvisService, "Falta el permiso del micrófono.", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    crearReconocedor()
                    programarReintento(1000)
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> programarReintento(300)
                else -> programarReintento(2000)
            }
        }

        override fun onResults(results: Bundle?) {
            val lista = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val texto = lista?.firstOrNull()
            if (!texto.isNullOrBlank()) procesar(texto)
            if (!hablando) programarReintento(300)
        }
    }

    private fun crearReconocedor() {
        reconocedor?.destroy()
        reconocedor = SpeechRecognizer.createSpeechRecognizer(this)
        reconocedor?.setRecognitionListener(listener)
    }

    private fun programarReintento(ms: Long) {
        main.removeCallbacks(reintento)
        main.postDelayed(reintento, ms)
    }

    private fun escuchar() {
        if (!corriendo || hablando || reconocedor == null) return
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            reconocedor?.startListening(i)
        } catch (e: Exception) {
            programarReintento(1500)
        }
    }

    // ------------------------------------------------------------ interpretación

    private fun normalizar(s: String): String {
        val sinAcentos = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        return sinAcentos.replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun procesar(original: String) {
        val t = normalizar(original)
        if (t.isEmpty()) return
        textoOriginal = original
        val ahora = System.currentTimeMillis()
        if (activo && ahora - ultimaActividad > ventanaMs) activo = false

        // Confirmación pendiente (por ejemplo, antes de enviar un mensaje)
        val p = pendiente
        if (p != null) {
            if (ahora > pendienteHasta) {
                pendiente = null
            } else if (activo) {
                if (Regex("\\b(si|dale|envialo|enviar|adelante|claro|confirmo)\\b").containsMatchIn(t)) {
                    pendiente = null
                    ultimaActividad = ahora
                    p()
                    return
                }
                if (Regex("\\b(no|cancela|cancelar|cancelalo|mejor no)\\b").containsMatchIn(t)) {
                    pendiente = null
                    decir("Cancelado, señor.")
                    return
                }
            }
        }

        val llamado = patronJarvis.containsMatchIn(t)
        if (!activo && !llamado) return
        activo = true
        ultimaActividad = ahora

        val cmd = t.replace(patronJarvis, " ").replace(Regex("\\s+"), " ").trim()
        if (cmd.isEmpty()) {
            decir("Dígame, señor.")
            return
        }
        ejecutar(cmd, llamado)
    }

    private fun ejecutar(c: String, llamado: Boolean) {
        when {
            Regex("\\b(cuelga|colgar|cuelgale|termina la llamada|finaliza la llamada)\\b").containsMatchIn(c) -> colgar()
            Regex("^(contesta|contestar|responde|responder|atiende|atender|acepta|aceptar)\\b").containsMatchIn(c) -> contestar()
            Regex("^(llama|llamar|marca|marcar|telefonea)\\b").containsMatchIn(c) ->
                llamar(c.replaceFirst(Regex("^(llama|llamar|marca|marcar|telefonea)( a la| a| al)?\\s*"), "").trim())
            Regex("\\b(manda|mandale|envia|enviale|escribe|escribele)\\b").containsMatchIn(c) &&
                Regex("\\b(mensaje|sms|texto)\\b").containsMatchIn(c) -> mensaje(c)
            c.contains("recuerd") -> recordatorio(c)
            Regex("\\b(temporizador|avisame en|cronometro)\\b").containsMatchIn(c) -> temporizador(c)
            Regex("\\b(alarma|despiertame)\\b").containsMatchIn(c) -> alarma(c)
            c.contains("que hora") -> hora()
            Regex("\\b(que dia|que fecha|fecha de hoy)\\b").containsMatchIn(c) -> fecha()
            Regex("\\b(sube|subir|aumenta)\\b.*\\bvolumen\\b").containsMatchIn(c) -> volumen(AudioManager.ADJUST_RAISE)
            Regex("\\b(baja|bajar|reduce)\\b.*\\bvolumen\\b").containsMatchIn(c) -> volumen(AudioManager.ADJUST_LOWER)
            Regex("\\b(siguiente|proxima)\\b").containsMatchIn(c) -> tecla(KeyEvent.KEYCODE_MEDIA_NEXT)
            Regex("\\b(anterior)\\b").containsMatchIn(c) -> tecla(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            Regex("\\b(musica|cancion|reproduce|reproducir|continua|reanuda|pausa|pausar|deten|detener|detente|calla|silencio)\\b|\\bpara (la|el|esto)\\b")
                .containsMatchIn(c) -> musica(c)
            Regex("\\b(gracias|descansa|eso es todo|ya no)\\b").containsMatchIn(c) -> {
                activo = false
                decir("A sus órdenes, señor.")
            }
            llamado -> decir("No entendí la orden, señor.")
        }
    }

    // ------------------------------------------------------------ llamadas

    private val receptorLlamadas = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val estado = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            if (estado == TelephonyManager.EXTRA_STATE_RINGING) {
                val numero = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                main.removeCallbacks(fallbackLlamada)
                if (numero.isNullOrBlank()) {
                    main.postDelayed(fallbackLlamada, 1500)
                } else {
                    anunciarLlamada(numero)
                }
            } else {
                main.removeCallbacks(fallbackLlamada)
                llamadaSonando = false
            }
        }
    }

    private fun registrarReceptorLlamadas() {
        val filtro = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receptorLlamadas, filtro, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receptorLlamadas, filtro)
        }
    }

    private fun anunciarLlamada(numero: String?) {
        if (llamadaSonando) return
        llamadaSonando = true
        activo = true
        ultimaActividad = System.currentTimeMillis()
        val nombre = if (numero != null) {
            nombreDeContacto(numero) ?: numero.toCharArray().joinToString(" ")
        } else null
        if (nombre != null) {
            decir("Señor, tiene una llamada de $nombre. Diga contesta para responder.")
        } else {
            decir("Señor, tiene una llamada. Diga contesta para responder.")
        }
    }

    private fun telecom(): TelecomManager = getSystemService(TelecomManager::class.java)

    private fun contestar() {
        try {
            telecom().acceptRingingCall()
        } catch (e: SecurityException) {
            decir("Me falta el permiso para contestar llamadas.")
        } catch (e: Exception) {
            decir("No pude contestar la llamada.")
        }
    }

    private fun colgar() {
        try {
            telecom().endCall()
        } catch (e: SecurityException) {
            decir("Me falta el permiso para colgar llamadas.")
        } catch (e: Exception) {
            decir("No pude colgar la llamada.")
        }
    }

    private fun marcar(numero: String) {
        try {
            telecom().placeCall(Uri.fromParts("tel", numero, null), Bundle())
        } catch (e: SecurityException) {
            decir("Me falta el permiso para hacer llamadas.")
        } catch (e: Exception) {
            decir("No pude hacer la llamada.")
        }
    }

    private fun llamar(nombre: String) {
        val digitos = nombre.filter { it.isDigit() }
        if (digitos.length >= 7) {
            decir("Llamando.")
            main.postDelayed({ marcar(digitos) }, 1200)
            return
        }
        if (nombre.isBlank()) {
            decir("¿A quién llamo, señor?")
            return
        }
        val contacto = buscarContacto(nombre)
        if (contacto == null) {
            decir("No encontré a $nombre en sus contactos.")
        } else {
            decir("Llamando a ${contacto.first}.")
            main.postDelayed({ marcar(contacto.second) }, 1500)
        }
    }

    // ------------------------------------------------------------ mensajes

    private fun mensaje(c: String) {
        val m = Regex(
            "(?:manda|mandale|envia|enviale|escribe|escribele)\\s+(?:un\\s+)?(?:mensaje|sms|texto)" +
                "(?:\\s+de\\s+texto)?\\s+a\\s+(.+?)\\s+(?:que diga|que dice|diciendo|que)\\s+(.+)"
        ).find(c)
        if (m == null) {
            decir("Dígame así: manda mensaje a nombre, que diga, y el mensaje.")
            return
        }
        val nombre = m.groupValues[1]
        val mo = Regex("(?i)(?:que\\s+diga|que\\s+dice|diciendo)\\s+(.+)$").find(textoOriginal)
            ?: Regex("(?i)\\bque\\s+(.+)$").find(textoOriginal)
        val texto = (mo?.groupValues?.get(1) ?: m.groupValues[2]).trim()
            .replaceFirstChar { it.uppercase() }

        val contacto = buscarContacto(nombre)
        if (contacto == null) {
            decir("No encontré a $nombre en sus contactos.")
            return
        }
        pendiente = { enviarSms(contacto.second, texto) }
        pendienteHasta = System.currentTimeMillis() + 20_000L
        decir("Voy a enviar a ${contacto.first}: $texto. ¿Lo envío?")
    }

    @Suppress("DEPRECATION")
    private fun enviarSms(numero: String, texto: String) {
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            sms.sendMultipartTextMessage(numero, null, sms.divideMessage(texto), null, null)
            decir("Mensaje enviado, señor.")
        } catch (e: SecurityException) {
            decir("Me falta el permiso para enviar mensajes.")
        } catch (e: Exception) {
            decir("No pude enviar el mensaje.")
        }
    }

    // ------------------------------------------------------------ contactos

    private fun buscarContacto(nombre: String): Pair<String, String>? {
        val buscado = normalizar(nombre)
        if (buscado.isEmpty()) return null
        val palabras = buscado.split(" ")
        var mejor: Pair<String, String>? = null
        var mejorPuntos = 0
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val nom = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    val nn = normalizar(nom)
                    val puntos = when {
                        nn == buscado -> 4
                        nn.startsWith(buscado) -> 3
                        palabras.all { nn.contains(it) } -> 2
                        else -> 0
                    }
                    if (puntos > mejorPuntos) {
                        mejorPuntos = puntos
                        mejor = Pair(nom, num)
                    }
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return mejor
    }

    private fun nombreDeContacto(numero: String): String? {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(numero)
            )
            contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ música y volumen

    private fun tecla(code: Int) {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun musica(c: String) {
        val pausa = Regex("\\b(pausa|pausar|deten|detener|detente|calla|silencio)\\b|\\bpara (la|el|esto)\\b")
            .containsMatchIn(c)
        if (pausa) {
            tecla(KeyEvent.KEYCODE_MEDIA_PAUSE)
        } else {
            decir("Reproduciendo, señor.")
            main.postDelayed({ tecla(KeyEvent.KEYCODE_MEDIA_PLAY) }, 1800)
        }
    }

    private fun volumen(direccion: Int) {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        a.adjustStreamVolume(AudioManager.STREAM_MUSIC, direccion, AudioManager.FLAG_SHOW_UI)
    }

    // ------------------------------------------------------------ hora, alarmas, recordatorios

    private fun hora() {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val periodo = when {
            h < 12 -> "de la mañana"
            h < 19 -> "de la tarde"
            else -> "de la noche"
        }
        val inicio = if (h12 == 1) "Es la una" else "Son las $h12"
        val minutos = if (m == 0) "en punto" else "con $m minutos"
        decir("$inicio $minutos $periodo, señor.")
    }

    private fun fecha() {
        val f = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "MX"))
        decir("Hoy es ${f.format(Date())}, señor.")
    }

    private fun palabrasANumeros(t: String): String {
        var r = t
        for ((palabra, n) in numeros.entries.sortedByDescending { it.key.length }) {
            r = r.replace(Regex("\\b$palabra\\b(?= (segundos?|minutos?|horas?)\\b)"), n.toString())
            r = r.replace(Regex("(?<=\\ba las )$palabra\\b"), n.toString())
            r = r.replace(Regex("(?<=\\ba la )$palabra\\b"), n.toString())
        }
        return r
    }

    private fun duracionMs(t: String): Long? {
        if (Regex("\\bmedia hora\\b").containsMatchIn(t)) return 30 * 60_000L
        val m = Regex("\\ben (\\d+) (segundos?|minutos?|horas?)").find(t) ?: return null
        val n = m.groupValues[1].toLongOrNull() ?: return null
        val unidad = m.groupValues[2]
        return when {
            unidad.startsWith("seg") -> n * 1000L
            unidad.startsWith("min") -> n * 60_000L
            else -> n * 3_600_000L
        }
    }

    private fun parsearHora(t: String): Pair<Int, Int>? {
        val m = Regex("a las? (\\d{1,2})(?: ?(?:y )?(\\d{2}|media|cuarto))?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val extra = m.groupValues[2]
        val min = when (extra) {
            "" -> 0
            "media" -> 30
            "cuarto" -> 15
            else -> extra.toInt()
        }
        if (h > 23 || min > 59) return null
        if (Regex("de la (tarde|noche)").containsMatchIn(t) && h < 12) h += 12
        if (Regex("de la manana").containsMatchIn(t) && h == 12) h = 0
        return Pair(h, min)
    }

    private fun retrasoHasta(h: Int, min: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, min)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis - System.currentTimeMillis()
    }

    private fun describir(ms: Long): String {
        val seg = ms / 1000
        return when {
            seg >= 3600 -> {
                val h = seg / 3600
                "$h " + if (h == 1L) "hora" else "horas"
            }
            seg >= 60 -> {
                val m = seg / 60
                "$m " + if (m == 1L) "minuto" else "minutos"
            }
            else -> "$seg segundos"
        }
    }

    private fun programar(retrasoMs: Long, mensaje: String, veces: Int) {
        main.postDelayed({
            activo = true
            ultimaActividad = System.currentTimeMillis()
            repeat(veces) { decir(mensaje) }
        }, retrasoMs)
    }

    private fun temporizador(c: String) {
        val t = palabrasANumeros(c)
        val ms = duracionMs(t)
        if (ms == null) {
            decir("Dígame así: temporizador de 10 minutos.")
            return
        }
        programar(ms, "Señor, el temporizador terminó.", 3)
        decir("Temporizador de ${describir(ms)} listo, señor.")
    }

    private fun alarma(c: String) {
        val t = palabrasANumeros(c)
        val hm = parsearHora(t)
        if (hm == null) {
            decir("Dígame así: alarma a las 7 y media.")
            return
        }
        programar(retrasoHasta(hm.first, hm.second), "Señor, es la hora de su alarma.", 3)
        decir("Alarma programada a las ${hm.first}:${"%02d".format(hm.second)}, señor.")
    }

    private fun recordatorio(c: String) {
        val t = palabrasANumeros(c)
        val dur = duracionMs(t)
        val hm = parsearHora(t)
        if (dur == null && hm == null) {
            decir("Dígame así: recuérdame a las 6 tomar agua, o recuérdame en 10 minutos llamar a mi mamá.")
            return
        }
        var resto = t
            .replace(Regex("\\b(recuerdame|recuerda me)\\b"), " ")
            .replace(Regex("\\ben \\d+ (segundos?|minutos?|horas?)\\b"), " ")
            .replace(Regex("\\bmedia hora\\b"), " ")
            .replace(Regex("\\ba las? \\d{1,2}( y)?( \\d{2}| media| cuarto)?( de la (manana|tarde|noche))?"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        resto = resto.replace(Regex("^(que|de|a)\\s+"), "").trim()
        if (resto.isEmpty()) resto = "es la hora"

        val retraso = dur ?: retrasoHasta(hm!!.first, hm.second)
        programar(retraso, "Señor, recordatorio: $resto.", 2)
        decir("Anotado, señor. Se lo recordaré en ${describir(retraso)}.")
    }
}
