package com.jarvis.movil

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var estado: TextView
    private var ttsPrueba: TextToSpeech? = null
    private val oyente = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { refrescar() }
    }

    private fun permisosNecesarios(): Array<String> {
        val lista = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) {
            lista.add(Manifest.permission.POST_NOTIFICATIONS)
            lista.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            lista.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return lista.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setPadding(48, 64, 48, 48)

        val titulo = TextView(this)
        titulo.text = "JARVIS móvil 13.0"
        titulo.textSize = 28f
        raiz.addView(titulo)

        estado = TextView(this)
        estado.textSize = 16f
        estado.setPadding(0, 24, 0, 24)
        raiz.addView(estado)

        raiz.addView(boton("1. Dar permisos") {
            requestPermissions(permisosNecesarios(), 1)
        })
        raiz.addView(boton("2. Quitar ahorro de batería") {
            try {
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        raiz.addView(boton("3. Permitir sobre otras apps") {
            try {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo abrir esa pantalla.", Toast.LENGTH_LONG).show()
            }
        })
        raiz.addView(boton("4. Iniciar JARVIS") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Primero dé los permisos (paso 1).", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
                Toast.makeText(
                    this,
                    "JARVIS iniciado. La primera vez tarda 1 o 2 minutos en preparar la voz.",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
        raiz.addView(boton("Cambiar modo del micrófono") {
            val p = getSharedPreferences("jarvis", MODE_PRIVATE)
            val nuevo = if (p.getString("mic", "eco") == "eco") "normal" else "eco"
            p.edit().putString("mic", nuevo).apply()
            val texto = if (nuevo == "eco") {
                "Modo MÚSICA: cancela el eco de la música."
            } else {
                "Modo NORMAL: más alcance, sin música."
            }
            Toast.makeText(this, "$texto Detenga e inicie JARVIS.", Toast.LENGTH_LONG).show()
        })
        raiz.addView(boton("Cambiar voz de JARVIS") {
            elegirVoz()
        })
        raiz.addView(boton("Detener JARVIS") {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "JARVIS detenido.", Toast.LENGTH_SHORT).show()
        })

        val ayuda = TextView(this)
        ayuda.textSize = 15f
        ayuda.setPadding(0, 32, 0, 0)
        ayuda.text = "Ejemplos (diga primero «Jarvis»):\n" +
            "• Jarvis, llama a Mamá\n" +
            "• Jarvis, contesta / Jarvis, cuelga\n" +
            "• Jarvis, manda mensaje a Juan que diga voy tarde\n" +
            "• Jarvis, manda WhatsApp a Juan que diga voy tarde\n" +
            "• Jarvis, reproduce la música del celular\n" +
            "• Jarvis, pon [canción o artista]\n" +
            "• Jarvis, abre YouTube\n" +
            "• Jarvis, pon [canción] en YouTube\n" +
            "• Jarvis, abre WhatsApp (o cualquier app)\n" +
            "• Jarvis, pausa / siguiente / anterior\n" +
            "• Jarvis, volumen al 30 por ciento (o: sube hasta el número 90)\n" +
            "• Jarvis, emergencia (pregunta si llama al 911)\n" +
            "• Jarvis, llama por WhatsApp a Juan\n" +
            "• Jarvis, llévame a [lugar]\n" +
            "• Jarvis, busca farmacias cerca\n" +
            "• Jarvis, recuérdame todos los días a las 8 tomar mi medicamento\n" +
            "• Jarvis, busca la fotosíntesis\n" +
            "• Jarvis, recuérdame a las 6 tomar agua\n" +
            "• Jarvis, temporizador de 10 minutos\n" +
            "• Jarvis, alarma a las 7 y media (al sonar te saluda y te dice el clima)\n" +
            "• Jarvis, alarma a las 15:30 / alarma todos los días a las 6\n" +
            "• Jarvis, cuál es tu misión / qué puedes hacer\n" +
            "• Jarvis, qué hora es\n" +
            "• Jarvis, qué clima hace\n" +
            "• Jarvis, abre las cámaras\n\n" +
            "Después de 30 segundos sin hablarle, vuelve a esperar la palabra «Jarvis»."
        raiz.addView(ayuda)

        val scroll = ScrollView(this)
        scroll.addView(raiz)
        setContentView(scroll)
    }

    private fun elegirVoz() {
        ttsPrueba?.shutdown()
        ttsPrueba = TextToSpeech(this) { codigo ->
            if (codigo != TextToSpeech.SUCCESS) {
                runOnUiThread {
                    Toast.makeText(this, "No se pudo abrir el motor de voz.", Toast.LENGTH_LONG).show()
                }
            } else {
                val voces = (ttsPrueba?.voices ?: emptySet<Voice>())
                    .filter { it.locale.language == "es" }
                    .sortedBy { it.name }
                runOnUiThread { mostrarVoces(voces) }
            }
        }
    }

    private fun mostrarVoces(voces: List<Voice>) {
        if (voces.isEmpty()) {
            Toast.makeText(this, "No encontré voces en español. Instálelas en Ajustes > Texto a voz.", Toast.LENGTH_LONG).show()
            return
        }
        val nombres = voces.mapIndexed { i, v ->
            val pais = when (v.locale.country) {
                "US" -> "Estados Unidos"
                "ES" -> "España"
                "MX" -> "México"
                else -> v.locale.country
            }
            val tipo = if (v.isNetworkConnectionRequired) "con internet" else "sin internet"
            "Voz ${i + 1} ($pais, $tipo)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Toque una voz para escucharla")
            .setItems(nombres) { _, i ->
                val v = voces[i]
                ttsPrueba?.voice = v
                ttsPrueba?.speak("Hola, soy Jarvis. ¿Así le gusta mi voz?", TextToSpeech.QUEUE_FLUSH, null, "prueba")
                getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("voz", v.name).apply()
                Toast.makeText(this, "Voz guardada. Detenga e inicie JARVIS.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    override fun onDestroy() {
        ttsPrueba?.shutdown()
        super.onDestroy()
    }

    private fun boton(texto: String, accion: () -> Unit): Button {
        val b = Button(this)
        b.text = texto
        b.setOnClickListener { accion() }
        return b
    }

    override fun onResume() {
        super.onResume()
        refrescar()
        getSharedPreferences("jarvis", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(oyente)
    }

    override fun onPause() {
        super.onPause()
        getSharedPreferences("jarvis", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(oyente)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refrescar()
    }

    private fun refrescar() {
        val faltan = permisosNecesarios().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        val permisos = if (faltan.isEmpty()) {
            "Permisos: todos concedidos ✔"
        } else {
            "Faltan ${faltan.size} permisos. Toque «1. Dar permisos»."
        }
        val sobre = if (Settings.canDrawOverlays(this)) {
            "Sobre otras apps: permitido ✔"
        } else {
            "Sobre otras apps: falta (paso 3)"
        }
        val ultimo = getSharedPreferences("jarvis", MODE_PRIVATE).getString("hist", "")?.ifBlank { "(nada todavía)" } ?: "(nada todavía)"
        estado.text = "Voz sin internet: se prepara al iniciar\n$permisos\n$sobre\nLo último que escuché:\n$ultimo"
    }
}
