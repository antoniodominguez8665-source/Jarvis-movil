import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.movil"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.movil"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}

// Descarga el modelo de voz en español (funciona sin internet) y lo mete en la app.
val descargarModelo by tasks.registering {
    val destino = file("src/main/assets/model-es")
    val zip = layout.buildDirectory.file("modelo-es.zip").get().asFile
    doLast {
        if (!File(destino, "am/final.mdl").exists()) {
            zip.parentFile.mkdirs()
            URL("https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip").openStream().use { entrada ->
                zip.outputStream().use { salida -> entrada.copyTo(salida) }
            }
            copy {
                from(zipTree(zip))
                into(destino)
                eachFile { path = path.substringAfter('/') }
                includeEmptyDirs = false
            }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(descargarModelo)
}
