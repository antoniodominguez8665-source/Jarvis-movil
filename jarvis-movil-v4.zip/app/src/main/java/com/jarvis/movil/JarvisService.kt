package com.jarvis.movil

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.roundToInt

private data class Pista(val uri: Uri, val titulo: String, val artista: String, val album: String)

@SuppressLint("MissingPermission")
class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())

    // Voz (TTS)
    private var tts: TextToSpeech? = null
    private var ttsListo = false
    private val pendientesHabla = AtomicInteger(0)
    private var hablando = false

    // Escucha sin internet (Vosk): sin pitidos y sin interrumpir la música
    private var modelo: Model? = null
    private var escucha: SpeechService? = null
    private var modeloListo = false
    private var saludado = false
    private var corriendo = false

    // Ventana de atención: tras hablarle, JARVIS atiende 30 s sin pedir "Jarvis".
    private var activo = false
    private var ultimaActividad = 0L
    private val ventanaMs = 30_000L

    private var pendiente: (() -> Unit)? = null
    private var pendienteHasta = 0L
    private var textoOriginal = ""

    private var wakeLock: PowerManager.WakeLock? = null
    private var llamadaSonando = false

    // Música local
    private var player: MediaPlayer? = null
    private var cola: List<Pista> = emptyList()
    private var indice = 0
    private var erroresSeguidos = 0
    private var pausaUsuario = false
    private var focoReq: AudioFocusRequest? = null

    private val fallbackLlamada = Runnable { anunciarLlamada(null) }
    private val reanudarEscucha = Runnable { if (!hablando) escucha?.setPause(false) }

    private val patronWA = "(whatsapp|wasap|wazap|guasap|guatsap|watsap|wats app)"
    private val codigoPais = "52"

    private val numeros = linkedMapOf(
        "una" to 1, "un" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10,
        "once" to 11, "doce" to 12, "quince" to 15, "veinte" to 20, "treinta" to 30,
        "cuarenta y cinco" to 45, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60
    )

    // ------------------------------------------------------------ ciclo de vida

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        corriendo = true
        try {
            crearNotificacion()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar: revise los permisos.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:escucha")
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire()

        tts = TextToSpeech(this, this)
        registrarReceptorLlamadas()
        cargarRecordatorios()
        prepararVoz()
    }

    override fun onDestroy() {
        corriendo = false
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receptorLlamadas) } catch (e: Exception) { }
        try { escucha?.stop() } catch (e: Exception) { }
        try { escucha?.shutdown() } catch (e: Exception) { }
        escucha = null
        try { modelo?.close() } catch (e: Exception) { }
        modelo = null
        detenerPlayer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun crearNotificacion() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS activo")
            .setContentText("Escuchando. Diga «Jarvis».")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ------------------------------------------------------------ voz (TTS)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("es", "MX"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale("es"))
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { terminoHabla() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { terminoHabla() }
        })
        main.post {
            ttsListo = true
            revisarListo()
        }
    }

    private fun revisarListo() {
        if (ttsListo && modeloListo && !saludado) {
            saludado = true
            decir("Jarvis en línea, señor.")
        }
    }

    private fun decir(texto: String) {
        main.post {
            if (!ttsListo || !corriendo) return@post
            hablando = true
            pendientesHabla.incrementAndGet()
            escucha?.setPause(true)
            player?.setVolume(0.25f, 0.25f)
            main.removeCallbacks(reanudarEscucha)
            val r = tts?.speak(texto, TextToSpeech.QUEUE_ADD, null, "j" + System.nanoTime())
            if (r != TextToSpeech.SUCCESS) terminoHabla()
        }
    }

    private fun terminoHabla() {
        main.post {
            if (pendientesHabla.decrementAndGet() <= 0) {
                pendientesHabla.set(0)
                hablando = false
                ultimaActividad = System.currentTimeMillis()
                player?.setVolume(1f, 1f)
                main.removeCallbacks(reanudarEscucha)
                main.postDelayed(reanudarEscucha, 500)
            }
        }
    }

    // ------------------------------------------------------------ escucha (Vosk)

    private fun copiarAssets(origen: String, destino: File) {
        val hijos = assets.list(origen) ?: return
        if (hijos.isEmpty()) {
            destino.parentFile?.mkdirs()
            assets.open(origen).use { entrada ->
                destino.outputStream().use { salida -> entrada.copyTo(salida) }
            }
        } else {
            destino.mkdirs()
            for (h in hijos) copiarAssets("$origen/$h", File(destino, h))
        }
    }

    private fun prepararVoz() {
        Thread {
            try {
                val destino = File(filesDir, "model-es")
                if (!File(destino, "am/final.mdl").exists()) {
                    copiarAssets("model-es", destino)
                }
                val m = Model(destino.absolutePath)
                main.post {
                    if (!corriendo) {
                        m.close()
                    } else {
                        modelo = m
                        iniciarEscucha()
                        modeloListo = true
                        revisarListo()
                    }
                }
            } catch (e: Exception) {
                main.post {
                    Toast.makeText(
                        this@JarvisService,
                        "No se pudo preparar la voz: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun iniciarEscucha() {
        val m = modelo ?: return
        try {
            escucha?.stop()
            escucha?.shutdown()
        } catch (e: Exception) { }
        try {
            val rec = Recognizer(m, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(vosk)
            escucha = s
        } catch (e: Exception) {
            main.postDelayed({ if (corriendo) iniciarEscucha() }, 3000)
        }
    }

    private val vosk = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}
        override fun onResult(hypothesis: String?) { textoDeVosk(hypothesis) }
        override fun onFinalResult(hypothesis: String?) { textoDeVosk(hypothesis) }
        override fun onError(exception: Exception?) {
            main.postDelayed({ if (corriendo) iniciarEscucha() }, 2000)
        }
        override fun onTimeout() {}
    }

    private fun textoDeVosk(json: String?) {
        if (json == null) return
        val t = try { JSONObject(json).optString("text", "") } catch (e: Exception) { "" }
        if (t.isNotBlank() && !hablando) procesar(t)
    }

    // ------------------------------------------------------------ interpretación

    private fun normalizar(s: String): String {
        val sinAcentos = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        return sinAcentos.replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun distancia(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val costo = if (a[i - 1] == b[j - 1]) 0 else 1
                d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo)
            }
        }
        return d[a.length][b.length]
    }

    // Reconoce "Jarvis" aunque la voz lo escuche parecido (harvis, yarvis, jarbis...)
    private fun esLlamado(tok: String): Boolean {
        if (tok.length < 4 || tok.length > 8) return false
        if (tok == "jarvis") return true
        return (tok.contains("ar") || tok.contains("er")) && distancia(tok, "jarvis") <= 2
    }

    private fun procesar(original: String) {
        val t = normalizar(original)
        if (t.isEmpty()) return
        textoOriginal = original
        val ahora = System.currentTimeMillis()
        if (activo && ahora - ultimaActividad > ventanaMs) activo = false

        // Confirmación pendiente (por ejemplo, antes de enviar un mensaje)
        val p = pendiente
        if (p != null) {
            if (ahora > pendienteHasta) {
                pendiente = null
            } else if (activo) {
                if (Regex("\\b(si|dale|envialo|enviar|adelante|claro|confirmo)\\b").containsMatchIn(t)) {
                    pendiente = null
                    ultimaActividad = ahora
                    p()
                    return
                }
                if (Regex("\\b(no|cancela|cancelar|cancelalo|mejor no)\\b").containsMatchIn(t)) {
                    pendiente = null
                    decir("Cancelado, señor.")
                    return
                }
            }
        }

        val tokens = t.split(" ")
        val llamado = tokens.any { esLlamado(it) }
        if (!activo && !llamado) return
        activo = true
        ultimaActividad = ahora

        val cmd = tokens.filterNot { esLlamado(it) }.joinToString(" ").trim()
        if (cmd.isEmpty()) {
            decir("Dígame, señor.")
            return
        }
        ejecutar(cmd, llamado)
    }

    private fun ejecutar(c: String, llamado: Boolean) {
        val pausaRe = Regex("\\b(pausa|pausar|deten|detener|detente|calla|silencio)\\b|\\bpara (la|el|esto)\\b")
        val buscaRe = Regex(
            "^(busca|buscame|buscar|investiga|investigame|que es|quien es|quien fue|" +
                "cuentame (sobre|de|acerca de)|dime (que es|quien es))\\b"
        )
        val abreRe = Regex("^(abre|abrir|abreme|lanza|ejecuta)\\b")
        val esYoutube = Regex("\\b(youtube|you tube)\\b").containsMatchIn(c) ||
            (Regex("^(reproduce|reproducir|pon|ponme|toca)\\b").containsMatchIn(c) &&
                Regex("\\b(video|videos)\\b").containsMatchIn(c))
        when {
            Regex("\\b(cuelga|colgar|cuelgale|termina la llamada|finaliza la llamada)\\b").containsMatchIn(c) -> colgar()
            Regex("^(contesta|contestar|responde|responder|atiende|atender|acepta|aceptar)\\b").containsMatchIn(c) -> contestar()
            Regex("\\b(llama|llamar|llamale|marca|marcale|videollamada|videollamar)\\b").containsMatchIn(c) &&
                Regex("\\b$patronWA\\b").containsMatchIn(c) -> llamarWhatsApp(c)
            Regex("^(llama|llamar|marca|marcar|telefonea)\\b").containsMatchIn(c) ->
                llamar(c.replaceFirst(Regex("^(llama|llamar|marca|marcar|telefonea)( a la| a| al)?\\s*"), "").trim())
            Regex("\\b(manda|mandale|envia|enviale|escribe|escribele)\\b").containsMatchIn(c) &&
                Regex("\\b(mensaje|sms|texto|$patronWA)\\b").containsMatchIn(c) -> mensaje(c)
            c.contains("recuerd") -> recordatorio(c)
            Regex("\\b(temporizador|avisame en|cronometro)\\b").containsMatchIn(c) -> temporizador(c)
            Regex("\\b(alarma|despiertame)\\b").containsMatchIn(c) -> alarma(c)
            c.contains("que hora") -> hora()
            Regex("\\b(que dia|que fecha|fecha de hoy)\\b").containsMatchIn(c) -> fecha()
            c.contains("volumen") && volumenPorcentaje(c) -> { }
            Regex("\\b(sube|subir|aumenta)\\b.*\\bvolumen\\b").containsMatchIn(c) -> volumen(AudioManager.ADJUST_RAISE)
            Regex("\\b(baja|bajar|reduce)\\b.*\\bvolumen\\b").containsMatchIn(c) -> volumen(AudioManager.ADJUST_LOWER)
            Regex("\\b(siguiente|proxima|otra cancion)\\b").containsMatchIn(c) -> siguiente()
            Regex("\\banterior\\b").containsMatchIn(c) -> anterior()
            pausaRe.containsMatchIn(c) -> pausar()
            Regex("\\b(continua|reanuda|sigue)\\b").containsMatchIn(c) -> continuarMusica()
            abreRe.containsMatchIn(c) && !esYoutube ->
                abrirApp(c.replaceFirst(Regex("^(abre|abrir|abreme|lanza|ejecuta)\\s*(la aplicacion|la app|el programa)?\\s*"), ""))
            esYoutube -> youtube(c)
            Regex("^(llevame|como llego|como llegar|navega|navegar|ruta|direcciones|indicaciones)\\b|\\b(donde hay|donde queda|donde esta)\\b|\\b(busca|buscame)\\b.*\\bcerca").containsMatchIn(c) -> mapas(c)
            buscaRe.containsMatchIn(c) -> buscarWiki(
                c.replaceFirst(buscaRe, "")
                    .replace(Regex("^\\s*(sobre|de|acerca de|en internet|en wikipedia|en google)\\b"), "")
                    .replace(Regex("^\\s*(la|el|los|las|un|una)\\b"), "")
                    .trim()
            )
            Regex("\\ben (spotify|amazon music|deezer)\\b").containsMatchIn(c) ->
                decir("Por ahora solo puedo reproducir la música de su teléfono o de YouTube.")
            Regex("^(reproduce|reproducir|pon|ponme|toca|escuchar|quiero escuchar)\\b|\\b(musica|cancion|canciones)\\b")
                .containsMatchIn(c) -> reproducirLocal(c)
            Regex("\\b(gracias|descansa|eso es todo|ya no)\\b").containsMatchIn(c) -> {
                activo = false
                decir("A sus órdenes, señor.")
            }
            llamado -> decir("No entendí la orden, señor.")
        }
    }

    // ------------------------------------------------------------ llamadas

    private val receptorLlamadas = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val estado = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            if (estado == TelephonyManager.EXTRA_STATE_RINGING) {
                val numero = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                main.removeCallbacks(fallbackLlamada)
                if (numero.isNullOrBlank()) {
                    main.postDelayed(fallbackLlamada, 1500)
                } else {
                    anunciarLlamada(numero)
                }
            } else {
                main.removeCallbacks(fallbackLlamada)
                llamadaSonando = false
            }
        }
    }

    private fun registrarReceptorLlamadas() {
        val filtro = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receptorLlamadas, filtro, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receptorLlamadas, filtro)
        }
    }

    private fun anunciarLlamada(numero: String?) {
        if (llamadaSonando) return
        llamadaSonando = true
        activo = true
        ultimaActividad = System.currentTimeMillis()
        val nombre = if (numero != null) {
            nombreDeContacto(numero) ?: numero.toCharArray().joinToString(" ")
        } else null
        if (nombre != null) {
            decir("Señor, tiene una llamada de $nombre. Diga contesta para responder.")
        } else {
            decir("Señor, tiene una llamada. Diga contesta para responder.")
        }
    }

    private fun telecom(): TelecomManager = getSystemService(TelecomManager::class.java)

    private fun contestar() {
        try {
            telecom().acceptRingingCall()
        } catch (e: SecurityException) {
            decir("Me falta el permiso para contestar llamadas.")
        } catch (e: Exception) {
            decir("No pude contestar la llamada.")
        }
    }

    private fun colgar() {
        try {
            telecom().endCall()
        } catch (e: SecurityException) {
            decir("Me falta el permiso para colgar llamadas.")
        } catch (e: Exception) {
            decir("No pude colgar la llamada.")
        }
    }

    private fun marcar(numero: String) {
        try {
            telecom().placeCall(Uri.fromParts("tel", numero, null), Bundle())
        } catch (e: SecurityException) {
            decir("Me falta el permiso para hacer llamadas.")
        } catch (e: Exception) {
            decir("No pude hacer la llamada.")
        }
    }

    private fun llamar(nombre: String) {
        val digitos = nombre.filter { it.isDigit() }
        if (digitos.length >= 7) {
            decir("Llamando.")
            main.postDelayed({ marcar(digitos) }, 1200)
            return
        }
        if (nombre.isBlank()) {
            decir("¿A quién llamo, señor?")
            return
        }
        val contacto = buscarContacto(nombre)
        if (contacto == null) {
            decir("No encontré a $nombre en sus contactos.")
        } else {
            decir("Llamando a ${contacto.first}.")
            main.postDelayed({ marcar(contacto.second) }, 1500)
        }
    }

    // ------------------------------------------------------------ mensajes (SMS y WhatsApp)

    private fun mensaje(cOriginal: String) {
        val porWA = Regex("\\b$patronWA\\b").containsMatchIn(cOriginal)
        val c = cOriginal
            .replace(Regex("\\bpor $patronWA\\b"), " ")
            .replace(Regex("\\b$patronWA\\b"), "mensaje")
            .replace(Regex("\\s+"), " ")
            .trim()
        val m = Regex(
            "(?:manda|mandale|envia|enviale|escribe|escribele)\\s+(?:un\\s+)?(?:mensaje|sms|texto)" +
                "(?:\\s+de\\s+texto)?\\s+a\\s+(.+?)\\s+(?:que diga|que dice|diciendo|que)\\s+(.+)"
        ).find(c)
        if (m == null) {
            decir("Dígame así: manda mensaje a nombre, que diga, y el mensaje.")
            return
        }
        val nombre = m.groupValues[1]
        val mo = Regex("(?i)(?:que\\s+diga|que\\s+dice|diciendo)\\s+(.+)$").find(textoOriginal)
            ?: Regex("(?i)\\bque\\s+(.+)$").find(textoOriginal)
        val texto = (mo?.groupValues?.get(1) ?: m.groupValues[2]).trim()
            .replaceFirstChar { it.uppercase() }

        val contacto = buscarContacto(nombre)
        if (contacto == null) {
            decir("No encontré a $nombre en sus contactos.")
            return
        }
        if (porWA) {
            if (!puedeAbrirApps()) return
            decir("Abriendo WhatsApp con su mensaje para ${contacto.first}. Toque enviar.")
            main.postDelayed({ abrirWhatsApp(contacto.second, texto) }, 2200)
        } else {
            pendiente = { enviarSms(contacto.second, texto) }
            pendienteHasta = System.currentTimeMillis() + 20_000L
            decir("Voy a enviar a ${contacto.first}: $texto. ¿Lo envío?")
        }
    }

    private fun abrirWhatsApp(numero: String, texto: String) {
        val digitos = numero.filter { it.isDigit() }
        val completo = when {
            numero.trim().startsWith("+") -> digitos
            digitos.startsWith("00") -> digitos.drop(2)
            digitos.length == 10 -> codigoPais + digitos
            else -> digitos
        }
        val uri = Uri.parse("https://wa.me/$completo?text=" + Uri.encode(texto))
        val i = Intent(Intent.ACTION_VIEW, uri)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            i.setPackage("com.whatsapp")
            startActivity(i)
        } catch (e: Exception) {
            try {
                i.setPackage(null)
                startActivity(i)
            } catch (e2: Exception) {
                decir("No pude abrir WhatsApp. Revise el permiso de mostrar sobre otras apps.")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun enviarSms(numero: String, texto: String) {
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            sms.sendMultipartTextMessage(numero, null, sms.divideMessage(texto), null, null)
            decir("Mensaje enviado, señor.")
        } catch (e: SecurityException) {
            decir("Me falta el permiso para enviar mensajes.")
        } catch (e: Exception) {
            decir("No pude enviar el mensaje.")
        }
    }

    // ------------------------------------------------------------ contactos

    private fun buscarContacto(nombre: String): Pair<String, String>? {
        val buscado = normalizar(nombre)
        if (buscado.isEmpty()) return null
        val palabras = buscado.split(" ")
        var mejor: Pair<String, String>? = null
        var mejorPuntos = 0
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val nom = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    val nn = normalizar(nom)
                    val puntos = when {
                        nn == buscado -> 4
                        nn.startsWith(buscado) -> 3
                        palabras.all { nn.contains(it) } -> 2
                        else -> 0
                    }
                    if (puntos > mejorPuntos) {
                        mejorPuntos = puntos
                        mejor = Pair(nom, num)
                    }
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return mejor
    }

    private fun nombreDeContacto(numero: String): String? {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(numero)
            )
            contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { cur -> if (cur.moveToFirst()) cur.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ música del teléfono

    private fun cargarPistas(): List<Pista> {
        val lista = mutableListOf<Pista>()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            contentResolver.query(
                base,
                arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM
                ),
                MediaStore.Audio.Media.IS_MUSIC + " != 0",
                null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getLong(0)
                    lista.add(
                        Pista(
                            ContentUris.withAppendedId(base, id),
                            cur.getString(1) ?: "",
                            cur.getString(2) ?: "",
                            cur.getString(3) ?: ""
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return lista
    }

    private fun reproducirLocal(c: String) {
        val q = normalizar(c)
            .replace(
                Regex("\\b(reproduce|reproducir|pon|ponme|toca|escuchar|quiero|musica|cancion|canciones|algo|de|del|la|el|una|un|mi|mis|por favor)\\b"),
                " "
            )
            .replace(Regex("\\s+"), " ")
            .trim()
        val todas = cargarPistas()
        val elegidas: List<Pista> = when {
            todas.isEmpty() -> emptyList()
            q.isEmpty() -> todas.shuffled()
            else -> {
                val palabras = q.split(" ").filter { it.length > 1 }
                val puntuadas = todas.map { pista ->
                    val texto = normalizar(pista.titulo + " " + pista.artista + " " + pista.album)
                    pista to palabras.count { texto.contains(it) }
                }
                val mejor = puntuadas.maxOfOrNull { it.second } ?: 0
                if (mejor == 0) emptyList() else puntuadas.filter { it.second == mejor }.map { it.first }.shuffled()
            }
        }
        if (elegidas.isEmpty()) {
            if (q.isNotEmpty()) {
                decir("No la encontré en su teléfono. La busco en YouTube.")
                if (puedeAbrirApps()) youtubeBuscar(q, false)
            } else {
                decir("No encontré música en su teléfono. Revise el permiso de audio.")
            }
            return
        }
        cola = elegidas
        indice = 0
        erroresSeguidos = 0
        pausaUsuario = false
        decir("Reproduciendo.")
        main.postDelayed({ tocar() }, 1500)
    }

    private fun pedirFoco() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener { cambio ->
                if (cambio == AudioManager.AUDIOFOCUS_LOSS || cambio == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    try { player?.pause() } catch (e: Exception) { }
                } else if (cambio == AudioManager.AUDIOFOCUS_GAIN && !pausaUsuario) {
                    try { player?.start() } catch (e: Exception) { }
                }
            }
            .build()
        focoReq = req
        audio.requestAudioFocus(req)
    }

    private fun tocar() {
        if (cola.isEmpty() || !corriendo) return
        detenerPlayer()
        val n = cola.size
        val pista = cola[((indice % n) + n) % n]
        pedirFoco()
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, pista.uri)
            mp.setOnPreparedListener {
                erroresSeguidos = 0
                it.start()
            }
            mp.setOnCompletionListener {
                indice++
                tocar()
            }
            mp.setOnErrorListener { _, _, _ ->
                erroresSeguidos++
                if (erroresSeguidos < 5) {
                    indice++
                    main.post { tocar() }
                } else {
                    decir("No pude reproducir esas canciones.")
                }
                true
            }
            mp.prepareAsync()
            player = mp
            pausaUsuario = false
        } catch (e: Exception) {
            try { mp.release() } catch (e2: Exception) { }
            decir("No pude reproducir esa canción.")
        }
    }

    private fun detenerPlayer() {
        try { player?.release() } catch (e: Exception) { }
        player = null
        val req = focoReq
        if (req != null) {
            try {
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audio.abandonAudioFocusRequest(req)
            } catch (e: Exception) { }
            focoReq = null
        }
    }

    private fun tecla(code: Int) {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun pausar() {
        pausaUsuario = true
        try { player?.pause() } catch (e: Exception) { }
        tecla(KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    private fun continuarMusica() {
        val p = player
        if (p != null) {
            pausaUsuario = false
            try { p.start() } catch (e: Exception) { }
        } else {
            tecla(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    private fun siguiente() {
        if (player != null && cola.isNotEmpty()) {
            indice++
            tocar()
        } else {
            tecla(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
    }

    private fun anterior() {
        if (player != null && cola.isNotEmpty()) {
            indice--
            tocar()
        } else {
            tecla(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
    }

    private fun volumen(direccion: Int) {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        a.adjustStreamVolume(AudioManager.STREAM_MUSIC, direccion, AudioManager.FLAG_SHOW_UI)
    }

    // ------------------------------------------------------------ volumen por porcentaje

    private val unidades = mapOf(
        "cero" to 0, "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4,
        "cinco" to 5, "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9
    )
    private val especiales = mapOf(
        "diez" to 10, "once" to 11, "doce" to 12, "trece" to 13, "catorce" to 14, "quince" to 15,
        "dieciseis" to 16, "diecisiete" to 17, "dieciocho" to 18, "diecinueve" to 19,
        "veinte" to 20, "veintiuno" to 21, "veintidos" to 22, "veintitres" to 23,
        "veinticuatro" to 24, "veinticinco" to 25, "veintiseis" to 26, "veintisiete" to 27,
        "veintiocho" to 28, "veintinueve" to 29
    )
    private val decenasMap = mapOf(
        "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60,
        "setenta" to 70, "ochenta" to 80, "noventa" to 90, "cien" to 100, "ciento" to 100
    )

    private fun extraerNumero(t: String): Int? {
        val digitos = Regex("\\b(\\d{1,3})\\b").find(t)
        if (digitos != null) return digitos.groupValues[1].toInt()
        val tk = t.split(" ")
        var i = 0
        while (i < tk.size) {
            val w = tk[i]
            val dec = decenasMap[w]
            if (dec != null) {
                var n: Int = dec
                if (dec < 100 && i + 2 < tk.size && tk[i + 1] == "y") {
                    val u = unidades[tk[i + 2]]
                    if (u != null) n += u
                }
                return n
            }
            val esp = especiales[w]
            if (esp != null) return esp
            val uni = unidades[w]
            if (uni != null) return uni
            i++
        }
        return null
    }

    private fun volumenPorcentaje(c: String): Boolean {
        val resto = c.substringAfter("volumen")
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val pct: Int? = when {
            Regex("\\b(maximo|full)\\b").containsMatchIn(resto) -> 100
            Regex("\\bminimo\\b").containsMatchIn(resto) -> 0
            else -> extraerNumero(resto)
        }
        if (pct == null) return false
        val p = pct.coerceIn(0, 100)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (max * p / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
        decir("Volumen al $p por ciento.")
        return true
    }

    // ------------------------------------------------------------ abrir apps, YouTube y WhatsApp

    private fun puedeAbrirApps(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        decir("Falta permitir mostrar sobre otras apps. Es el paso 3 en mi pantalla.")
        return false
    }

    private fun lanzarPaquete(paquete: String): Boolean {
        return try {
            val i = packageManager.getLaunchIntentForPackage(paquete) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun abrirApp(nombre: String) {
        val buscado = normalizar(nombre).replace(" ", "")
        if (buscado.isEmpty()) {
            decir("¿Qué aplicación quiere que abra, señor?")
            return
        }
        if (!puedeAbrirApps()) return
        val pm = packageManager
        val lanzador = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidatas = pm.queryIntentActivities(lanzador, 0).map {
            it.activityInfo.packageName to normalizar(it.loadLabel(pm).toString()).replace(" ", "")
        }
        val elegida = candidatas.firstOrNull { it.second == buscado }
            ?: candidatas.firstOrNull {
                it.second.contains(buscado) || (it.second.length >= 4 && buscado.contains(it.second))
            }
        if (elegida != null && lanzarPaquete(elegida.first)) {
            decir("Abriendo.")
        } else {
            decir("No encontré esa aplicación.")
        }
    }

    private fun youtube(c: String) {
        val q = c
            .replace(
                Regex("\\b(abre|abrir|abreme|lanza|ejecuta|reproduce|reproducir|pon|ponme|toca|busca|buscame|buscar|en|youtube|you tube|video|videos|musica|cancion|canciones|por favor)\\b"),
                " "
            )
            .replace(Regex("\\s+"), " ")
            .trim()
            .replace(Regex("^y\\s+"), "")
        if (!puedeAbrirApps()) return
        if (q.isEmpty()) {
            if (lanzarPaquete("com.google.android.youtube")) {
                decir("Abriendo YouTube.")
            } else {
                decir("No encontré YouTube en su teléfono.")
            }
            return
        }
        youtubeBuscar(q, true)
    }

    private fun youtubeBuscar(q: String, avisar: Boolean) {
        if (avisar) decir("Buscando $q en YouTube.")
        Thread {
            val id = try { buscarVideoId(q) } catch (e: Exception) { null }
            main.postDelayed({ abrirYouTube(id, q) }, 1800)
        }.start()
    }

    private fun buscarVideoId(q: String): String? {
        val url = "https://www.youtube.com/results?search_query=" +
            URLEncoder.encode(q, "UTF-8") + "&sp=EgIQAQ%3D%3D"
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 8000
        con.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
        )
        con.setRequestProperty("Accept-Language", "es-MX,es;q=0.9")
        val html = con.inputStream.bufferedReader().use { it.readText() }
        return Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)?.groupValues?.get(1)
    }

    private fun abrirYouTube(id: String?, q: String) {
        val uriApp = if (id != null) {
            Uri.parse("vnd.youtube:$id")
        } else {
            Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        }
        val i = Intent(Intent.ACTION_VIEW, uriApp)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            i.setPackage("com.google.android.youtube")
            startActivity(i)
        } catch (e: Exception) {
            try {
                val web = if (id != null) {
                    Uri.parse("https://www.youtube.com/watch?v=$id")
                } else {
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
                }
                val i2 = Intent(Intent.ACTION_VIEW, web)
                i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i2)
            } catch (e2: Exception) {
                decir("No pude abrir YouTube.")
            }
        }
    }

    private fun enviarWhatsApp(numero: String, texto: String) {
        if (!puedeAbrirApps()) return
        if (JarvisAccesibilidad.activo()) {
            JarvisAccesibilidad.armar(20_000L) { ok ->
                main.post {
                    if (ok) {
                        decir("Mensaje enviado por WhatsApp, señor.")
                    } else {
                        decir("No pude tocar el botón enviar. Tóquelo usted.")
                    }
                }
            }
            main.postDelayed({ JarvisAccesibilidad.expirar() }, 21_000L)
            abrirWhatsApp(numero, texto)
        } else {
            decir("Abriendo WhatsApp. Toque enviar.")
            main.postDelayed({ abrirWhatsApp(numero, texto) }, 3500)
        }
    }

    // ------------------------------------------------------------ llamadas por WhatsApp y mapas

    private fun llamarWhatsApp(c: String) {
        if (!puedeAbrirApps()) return
        val video = c.contains("video")
        val nombre = c
            .replace(Regex("\\b$patronWA\\b"), " ")
            .replace(Regex("\\b(llama|llamar|llamale|marca|marcale|videollamada|videollamar|por|de|una|un|en|audio|video|llamada|hazle|hazme)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .replace(Regex("^(a|al|a la)\\s+"), "")
        val buscado = normalizar(nombre)
        if (buscado.isEmpty()) {
            decir("¿A quién llamo por WhatsApp, señor?")
            return
        }
        val mime = if (video) {
            "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        } else {
            "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        }
        var dataId: Long? = null
        var nombreFinal = ""
        var mejor = 0
        try {
            contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME),
                ContactsContract.Data.MIMETYPE + " = ?",
                arrayOf(mime),
                null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getLong(0)
                    val nom = cur.getString(1) ?: continue
                    val nn = normalizar(nom)
                    val puntos = when {
                        nn == buscado -> 3
                        nn.startsWith(buscado) -> 2
                        buscado.split(" ").all { nn.contains(it) } -> 1
                        else -> 0
                    }
                    if (puntos > mejor) {
                        mejor = puntos
                        dataId = id
                        nombreFinal = nom
                    }
                }
            }
        } catch (e: Exception) {
        }
        val id = dataId
        if (id == null) {
            decir("No encontré a $nombre en WhatsApp.")
            return
        }
        decir(if (video) "Videollamada a $nombreFinal por WhatsApp." else "Llamando a $nombreFinal por WhatsApp.")
        main.postDelayed({
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse("content://com.android.contacts/data/$id"), mime)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                decir("No pude iniciar la llamada de WhatsApp.")
            }
        }, 1800)
    }

    private fun mapas(c: String) {
        if (!puedeAbrirApps()) return
        val cerca = Regex("\\bcerca\\b|\\bcercan[oa]s?\\b").containsMatchIn(c)
        val destino = c
            .replace(Regex("\\b(llevame|como llego|como llegar|navega|navegar|ruta|direcciones|indicaciones|busca|buscame|donde hay|donde queda|donde esta|a|al|hacia|en|cerca|cercano|cercana|cercanos|cercanas)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (destino.isEmpty()) {
            decir("¿A dónde quiere ir, señor?")
            return
        }
        val uri = if (cerca || Regex("\\b(donde hay)\\b").containsMatchIn(c)) {
            Uri.parse("geo:0,0?q=" + Uri.encode(destino))
        } else {
            Uri.parse("google.navigation:q=" + Uri.encode(destino))
        }
        decir(if (cerca) "Buscando $destino cerca de usted." else "Abriendo la ruta a $destino.")
        main.postDelayed({
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                i.setPackage("com.google.android.apps.maps")
                startActivity(i)
            } catch (e: Exception) {
                try {
                    i.setPackage(null)
                    startActivity(i)
                } catch (e2: Exception) {
                    decir("No pude abrir el mapa.")
                }
            }
        }, 1800)
    }

    // ------------------------------------------------------------ búsqueda de información

    private fun buscarWiki(tema: String) {
        if (tema.isEmpty()) {
            decir("¿Qué quiere que busque, señor?")
            return
        }
        decir("Buscando $tema.")
        Thread {
            val respuesta = try { consultarWiki(tema) } catch (e: Exception) { null }
            main.post {
                if (respuesta == null) {
                    decir("No pude encontrar información sobre $tema.")
                } else {
                    decir(respuesta)
                }
            }
        }.start()
    }

    private fun leerUrl(direccion: String): String {
        val c = URL(direccion).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "JarvisMovil/2.0 (asistente personal)")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun consultarWiki(tema: String): String? {
        val q = URLEncoder.encode(tema, "UTF-8")
        val busqueda = leerUrl(
            "https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&srlimit=1&format=json"
        )
        val resultados = JSONObject(busqueda).getJSONObject("query").getJSONArray("search")
        val titulo = resultados.optJSONObject(0)?.optString("title") ?: return null
        val t = URLEncoder.encode(titulo, "UTF-8").replace("+", "%20")
        val resumen = leerUrl("https://es.wikipedia.org/api/rest_v1/page/summary/$t")
        val extracto = JSONObject(resumen).optString("extract", "")
        if (extracto.isBlank()) return null
        val frases = extracto.split(Regex("(?<=[.!?])\\s+"))
        return frases.take(3).joinToString(" ")
    }

    // ------------------------------------------------------------ hora, alarmas, recordatorios

    private fun hora() {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val periodo = when {
            h < 12 -> "de la mañana"
            h < 19 -> "de la tarde"
            else -> "de la noche"
        }
        val inicio = if (h12 == 1) "Es la una" else "Son las $h12"
        val minutos = if (m == 0) "en punto" else "con $m minutos"
        decir("$inicio $minutos $periodo, señor.")
    }

    private fun fecha() {
        val f = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "MX"))
        decir("Hoy es ${f.format(Date())}, señor.")
    }

    private fun palabrasANumeros(t: String): String {
        var r = t
        for ((palabra, n) in numeros.entries.sortedByDescending { it.key.length }) {
            r = r.replace(Regex("\\b$palabra\\b(?= (segundos?|minutos?|horas?)\\b)"), n.toString())
            r = r.replace(Regex("(?<=\\ba las )$palabra\\b"), n.toString())
            r = r.replace(Regex("(?<=\\ba la )$palabra\\b"), n.toString())
        }
        return r
    }

    private fun duracionMs(t: String): Long? {
        if (Regex("\\bmedia hora\\b").containsMatchIn(t)) return 30 * 60_000L
        val m = Regex("\\ben (\\d+) (segundos?|minutos?|horas?)").find(t) ?: return null
        val n = m.groupValues[1].toLongOrNull() ?: return null
        val unidad = m.groupValues[2]
        return when {
            unidad.startsWith("seg") -> n * 1000L
            unidad.startsWith("min") -> n * 60_000L
            else -> n * 3_600_000L
        }
    }

    private fun parsearHora(t: String): Pair<Int, Int>? {
        val m = Regex("a las? (\\d{1,2})(?: ?(?:y )?(\\d{2}|media|cuarto))?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val extra = m.groupValues[2]
        val min = when (extra) {
            "" -> 0
            "media" -> 30
            "cuarto" -> 15
            else -> extra.toInt()
        }
        if (h > 23 || min > 59) return null
        if (Regex("de la (tarde|noche)").containsMatchIn(t) && h < 12) h += 12
        if (Regex("de la manana").containsMatchIn(t) && h == 12) h = 0
        return Pair(h, min)
    }

    private fun retrasoHasta(h: Int, min: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, min)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis - System.currentTimeMillis()
    }

    private fun describir(ms: Long): String {
        val seg = ms / 1000
        return when {
            seg >= 3600 -> {
                val h = seg / 3600
                "$h " + if (h == 1L) "hora" else "horas"
            }
            seg >= 60 -> {
                val m = seg / 60
                "$m " + if (m == 1L) "minuto" else "minutos"
            }
            else -> "$seg segundos"
        }
    }

    private fun programar(retrasoMs: Long, mensaje: String, veces: Int) {
        main.postDelayed({
            activo = true
            ultimaActividad = System.currentTimeMillis()
            repeat(veces) { decir(mensaje) }
        }, retrasoMs)
    }

    private fun temporizador(c: String) {
        val t = palabrasANumeros(c)
        val ms = duracionMs(t)
        if (ms == null) {
            decir("Dígame así: temporizador de 10 minutos.")
            return
        }
        programar(ms, "Señor, el temporizador terminó.", 3)
        decir("Temporizador de ${describir(ms)} listo, señor.")
    }

    private fun alarma(c: String) {
        val t = palabrasANumeros(c)
        val hm = parsearHora(t)
        if (hm == null) {
            decir("Dígame así: alarma a las 7 y media.")
            return
        }
        programar(retrasoHasta(hm.first, hm.second), "Señor, es la hora de su alarma.", 3)
        decir("Alarma programada a las ${hm.first}:${"%02d".format(hm.second)}, señor.")
    }

    private fun prefs() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private fun leerRecordatorios(): JSONArray {
        return try {
            JSONArray(prefs().getString("recordatorios", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun escribirRecordatorios(a: JSONArray) {
        prefs().edit().putString("recordatorios", a.toString()).apply()
    }

    private fun guardarRecordatorio(o: JSONObject) {
        val a = leerRecordatorios()
        a.put(o)
        escribirRecordatorios(a)
    }

    private fun borrarRecordatorio(id: Long) {
        val a = leerRecordatorios()
        val nuevo = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("id") != id) nuevo.put(o)
        }
        escribirRecordatorios(nuevo)
    }

    private fun agendar(o: JSONObject) {
        val id = o.optLong("id")
        val texto = o.optString("t")
        val diario = o.optBoolean("d", false)
        val retraso = if (diario) {
            retrasoHasta(o.optInt("h"), o.optInt("m"))
        } else {
            o.optLong("at") - System.currentTimeMillis()
        }
        if (retraso <= 0L) {
            borrarRecordatorio(id)
            return
        }
        main.postDelayed({
            activo = true
            ultimaActividad = System.currentTimeMillis()
            repeat(2) { decir("Señor, recordatorio: $texto.") }
            if (diario) agendar(o) else borrarRecordatorio(id)
        }, retraso)
    }

    private fun cargarRecordatorios() {
        val a = leerRecordatorios()
        for (i in 0 until a.length()) {
            agendar(a.getJSONObject(i))
        }
    }

    private fun recordatorio(c: String) {
        val t = palabrasANumeros(c)
        val diario = Regex("\\b(todos los dias|cada dia|diario|diariamente)\\b").containsMatchIn(t)
        val dur = duracionMs(t)
        val hm = parsearHora(t)
        if (dur == null && hm == null) {
            decir("Dígame así: recuérdame a las 6 tomar agua, o recuérdame todos los días a las 8 tomar mi medicamento.")
            return
        }
        var resto = t
            .replace(Regex("\\b(recuerdame|recuerda me)\\b"), " ")
            .replace(Regex("\\b(todos los dias|cada dia|diario|diariamente)\\b"), " ")
            .replace(Regex("\\ben \\d+ (segundos?|minutos?|horas?)\\b"), " ")
            .replace(Regex("\\bmedia hora\\b"), " ")
            .replace(Regex("\\ba las? \\d{1,2}( y)?( \\d{2}| media| cuarto)?( de la (manana|tarde|noche))?"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        resto = resto.replace(Regex("^(que|de|a)\\s+"), "").trim()
        if (resto.isEmpty()) resto = "es la hora"

        val o = JSONObject()
        o.put("id", System.currentTimeMillis())
        o.put("t", resto)
        if (diario && hm != null) {
            o.put("d", true)
            o.put("h", hm.first)
            o.put("m", hm.second)
            guardarRecordatorio(o)
            agendar(o)
            decir("Anotado, señor. Se lo recordaré todos los días a las ${hm.first}:${"%02d".format(hm.second)}.")
        } else {
            val retraso = dur ?: retrasoHasta(hm!!.first, hm.second)
            o.put("d", false)
            o.put("at", System.currentTimeMillis() + retraso)
            guardarRecordatorio(o)
            agendar(o)
            decir("Anotado, señor. Se lo recordaré en ${describir(retraso)}.")
        }
    }
}
